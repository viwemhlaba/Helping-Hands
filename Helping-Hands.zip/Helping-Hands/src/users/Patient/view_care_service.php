<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");

// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$contact_number = $_GET['contract_number'];
/* var_dump($contact_number);
exit(); */

// Connect to the patient_profile table and select everything using $user_ID
$queryPatientProfile = "SELECT * FROM patient_profile WHERE user_ID = $user_ID";
$resultPatientProfile = mysqli_query($conn, $queryPatientProfile);

if ($resultPatientProfile && mysqli_num_rows($resultPatientProfile) > 0) {
    $patientProfileData = mysqli_fetch_assoc($resultPatientProfile);
    $patient_ID = $patientProfileData['patient_ID'];

    // Connect to the care_contract table using contract_number and patient_ID to select everything and pull nurse_ID
    $queryCareContract = "SELECT * FROM care_contract WHERE patient_ID = $patient_ID AND contract_number = $contact_number";
    $resultCareContract = mysqli_query($conn, $queryCareContract);

    if ($resultCareContract && mysqli_num_rows($resultCareContract) > 0) {
        $careContractData = mysqli_fetch_assoc($resultCareContract);
        $nurse_ID = $careContractData['nurse_ID'];

        // Connect to the nurse_profile table using nurse_ID and select everything
        $queryNurseProfile = "SELECT * FROM nurse_profile WHERE nurse_ID = $nurse_ID";
        $resultNurseProfile = mysqli_query($conn, $queryNurseProfile);

        if ($resultNurseProfile && mysqli_num_rows($resultNurseProfile) > 0) {
            $nurseProfileData = mysqli_fetch_assoc($resultNurseProfile);

            // Connect to the care_visit table using contract_number and patient_ID to select everything
            $queryCareVisits = "SELECT * FROM care_visit WHERE patient_ID = $patient_ID AND contract_number = $contact_number";
            $resultCareVisits = mysqli_query($conn, $queryCareVisits);

            if ($resultCareVisits && mysqli_num_rows($resultCareVisits) > 0) {
                // Now you can work with the care visit data.
                $resultCareVisitsData = mysqli_fetch_assoc($resultCareVisits);

                //echo '<h1>' . $resultCareVisitsData['wound_progress'] . '</h1>';
                //var_dump($resultCareVisitsData['wound_progress']);
                //exit();
            } else {
                echo "No care visits found for this patient and contract.";
                echo mysqli_error($conn);
            }
        } else {
            echo "No nurse profile found for this nurse.";
        }
    } else {
        echo "No care contract found for this patient.";
    }
} else {
    echo "No patient profile found for this user.";
}
?>

<div class="content" id="content">
    <!-- Display the details of the current CARE CONTRACT here -->
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>
            </div>
        <?php } ?>
    </div>

    <div class="row align-items-center justify-content-between g-3 mb-4">
        <div class="col-auto">
            <h4 class="mb-0">Detailed Summary of visit</h4>
        </div>
        <div class="col-auto">
            <button id="exportButton" class="btn btn-phoenix-secondary me-2">
                <span class="fa-solid fa-download me-sm-2"></span>
                <span class="d-none d-sm-inline-block">Download As PDF</span>
            </button>
        </div>
    </div>


    <div class="bg-soft dark__bg-1100 p-4 mb-4 rounded-2">
        <div class="row g-4" style="display: none;">
            <!--patient information-->
            <div class="col-12 col-lg-3">
                <div class="row g-4 g-lg-2">
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h5 class="me-3">About Patient</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="mb-0 me-3">First Name :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($patientProfileData['first_name']) ? $patientProfileData['first_name'] : 'Not Set'; ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Last Name :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($patientProfileData['last_name']) ? $patientProfileData['last_name'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Identity Number :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($patientProfileData['id_number']) ? $patientProfileData['id_number'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Date of birth :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($patientProfileData['dob']) ? $patientProfileData['dob'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--patient information ends here-->

            <!--nurse information-->
            <div class="col-12 col-lg-3">
                <div class="row g-4 g-lg-2">
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h5 class="me-3">Responsible nurse</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="mb-0 me-3">First Name :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($nurseProfileData['first_name']) ? $nurseProfileData['first_name'] : 'Not Set'; ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Last Name :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($nurseProfileData['last_name']) ? $nurseProfileData['last_name'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Identity Number :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0" id="identity_number" value="<?php echo isset($nurseProfileData['id_number']) ? $nurseProfileData['id_number'] : 'Not Set'; ?>"><?php echo isset($nurseProfileData['id_number']) ? $nurseProfileData['id_number'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Nurse Code :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($nurseProfileData['nurse_code']) ? $nurseProfileData['nurse_code'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--nurse information ends here-->

            <div class="col-12 col-lg-3">
                <div class="row g-4 g-lg-2">
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h5 class="me-3">Care Contract</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="mb-0 me-3">Contract Date :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($careContractData['contract_date']) ? $careContractData['contract_date'] : 'Not Set'; ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="mb-0 me-3">Contract End Date :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($careContractData['care_end_date']) ? $careContractData['care_end_date'] : 'Not Set'; ?> </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Basic Wound Description :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($careContractData['wound_description']) ? $careContractData['wound_description'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-3">
                <div class="row g-4 g-lg-2">
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h5 class="me-3">Care Visit</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="mb-0 me-3">Visit Date :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($resultCareVisitsData['visit_date']) ? $resultCareVisitsData['visit_date'] : 'Not Set'; ?> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Visit Time :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($resultCareVisitsData['visit_time']) ? $resultCareVisitsData['visit_time'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Wound Progress :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($resultCareVisitsData['wound_progress']) ? $resultCareVisitsData['wound_progress'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-12">
                        <div class="row align-items-center g-0">
                            <div class="col-auto col-lg-6 col-xl-5">
                                <h6 class="me-3">Visit Notes :</h6>
                            </div>
                            <div class="col-auto col-lg-6 col-xl-7">
                                <p class="fs--1 text-800 fw-semi-bold mb-0"><?php echo isset($resultCareVisitsData['visit_notes']) ? $resultCareVisitsData['visit_notes'] : 'Not Set'; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <table>
                <tbody>
                    <tr>
                        <td>
                            <!-- Logo here -->
                            <img src="logo.png" alt="Company Logo">
                        </td>
                        <td>
                            <!-- Contract number -->
                            <?php echo $contact_number; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <!-- Patient information -->
                            <div>
                                <h5>Patient Information</h5>
                                <p>First Name: <?php echo isset($patientProfileData['first_name']) ? $patientProfileData['first_name'] : 'Not Set'; ?></p>
                                <p>Last Name: <?php echo isset($patientProfileData['last_name']) ? $patientProfileData['last_name'] : 'Not Set'; ?></p>
                                <p>ID Number: <?php echo isset($patientProfileData['id_number']) ? $patientProfileData['id_number'] : 'Not Set'; ?></p>
                                <p>Date of Birth: <?php echo isset($patientProfileData['dob']) ? $patientProfileData['dob'] : 'Not Set'; ?></p>
                            </div>
                        </td>
                        <td>
                            <!-- Nurse information -->
                            <div>
                                <h5>Nurse Information</h5>
                                <p>First Name: <?php echo isset($nurseProfileData['first_name']) ? $nurseProfileData['first_name'] : 'Not Set'; ?></p>
                                <p>Last Name: <?php echo isset($nurseProfileData['last_name']) ? $nurseProfileData['last_name'] : 'Not Set'; ?></p>
                                <p>ID Number: <?php echo isset($nurseProfileData['id_number']) ? $nurseProfileData['id_number'] : 'Not Set'; ?></p>
                                <p>Date of Birth: <?php echo isset($nurseProfileData['dob']) ? $nurseProfileData['dob'] : 'Not Set'; ?></p>
                            </div>
                        </td>
                        <td>
                            <!-- Care contract details -->
                            <div>
                                <h5>Care Contract Details</h5>
                                <p>Contract Date: <?php echo isset($careContractData['contract_date']) ? $careContractData['contract_date'] : 'Not Set'; ?></p>
                                <p>End Date: <?php echo isset($careContractData['care_end_date']) ? $careContractData['care_end_date'] : 'Not Set'; ?></p>
                                <p>Basic Wound Description: <?php echo isset($careContractData['wound_description']) ? $careContractData['wound_description'] : 'Not Set'; ?></p>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <!-- Information about the treatment plan / care visits goes here -->
                        <td colspan="3">
                            <div>
                                <!-- Include the care visits or treatment plan details here -->
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
    <!-- Display the details of past CARE VISITS here -->
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        function exportHTMLtoPDF() {
            let htmlElement = document.getElementById('content');
            html2pdf().from(htmlElement).save('exported_file.pdf');
        }
        document.getElementById('exportButton').addEventListener('click', exportHTMLtoPDF);
    });
</script>

<?php
/* } else {
    echo "No current CARE CONTRACT found.";
} */

include("../../includes/footer.php");
?>