<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');

// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];

if (isset($_GET['condition_ID']) && is_numeric($_GET['condition_ID'])) {
    // Get the ID from the URL
    $condition_ID = $_GET['condition_ID'];

    // Retrieve the patient's ID based on their user_ID
    $query = "SELECT patient_ID FROM patient_profile WHERE user_ID = '$user_ID'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $patient_ID = $row['patient_ID'];

        // Insert the selected condition into the patient's conditions
        $insertQuery = "INSERT INTO patient_chronic_conditions (patient_ID, condition_ID) VALUES ('$patient_ID', '$condition_ID')";
        $insertResult = mysqli_query($conn, $insertQuery);

        if ($insertResult) {
            $alertMessage = 'true';
        } else {
            $alertMessage = 'false';
        }
    }
}

// Redirect back to the conditions page with the alert message
header("Location: manage_condition.php?message=" . urlencode($alertMessage));
