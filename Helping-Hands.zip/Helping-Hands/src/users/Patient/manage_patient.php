<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");


// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

if (isset($_POST['update_patient_profile'])) {
    // Get the user_ID from the POST data
    $user_ID = $_POST['user_ID'];

    // Gather other POST data
    $email_address = $_POST['email_address'];
    $contact_no = $_POST['contact_no'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $id_number = $_POST['id_number'];
    $dob = $_POST['dob'];
    $profile_picture = $_POST['profile_picture'];
    $about_patient = $_POST['about_patient'];
    $street_name_add = $_POST['street_name_add'];
    $suburb_ID = $_POST['suburb_ID'];
    $ec_person = $_POST['ec_person'];
    $ecp_number = $_POST['ecp_number'];
    $fb_link = $_POST['fb_link'];
    $insta_link = $_POST['insta_link'];

    $result = update_profile(
        $conn,
        $user_ID,
        $email_address,
        $contact_no,
        $first_name,
        $last_name,
        $id_number,
        $dob,
        $profile_picture,
        $about_patient,
        $street_name_add,
        $suburb_ID,
        $ec_person,
        $ecp_number,
        $fb_link,
        $insta_link
    );    
}


// Your HTML and other content for the Admin dashboard
$user_ID_NEW = $user_ID;
$query = "CALL GetPatientProfileInfo($user_ID_NEW)";

$query_results = mysqli_query($conn, $query);
if (!$query_results) {
    die("Error: " . mysqli_error($conn));
    exit();
}
?>
<!--modals here-->
<div id="add_cities" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add More Cities</h5>
                <button class="btn p-1" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="fas fa-times fs--1"></span>
                </button>
            </div>
            <div class="modal-body">
                <form class="main_form" action="../../Global/functions.php" method="POST">
                    <div class="mb-3">
                        <label for="city_name" class="form-label form_label">Enter city name that you want to add.</label>
                        <input type="text" name="city_name" id="city_name" class="form-control error_input">
                        <span id="error_city_name" class="error"></span>
                    </div>
                    <div class="mb-3">
                        <label for="city_abr" class="form-label form_label">Whats the City Abbreviation name?</label>
                        <input type="text" name="city_abr" id="city_abr" class="form-control error_input">
                        <span id="error_city_abr" class="error"></span>
                    </div>


                    <div><button type="submit" name="add_city_btn" id="add_city_btn" class="btn btn-primary w-100 mb-0">Save Changes</button></div>
                </form>
            </div>
        </div>

    </div>
</div>

<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage ?>
            </div>
        <?php } ?>

    </div>

    <div class="mb-9">
        <div class="row align-items-center justify-content-between g-3 mb-4">

            <div class="col-auto">
                <h2 class="mb-0">Patient details</h2>
            </div>

            <div class="col-auto">
                <div class="row g-3">
                    <div class="col-auto">
                        <button class="btn btn-phoenix-danger">
                            <span class="fa-solid fa-trash-can me-2"></span>Delete patient
                        </button>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-phoenix-secondary">
                            <span class="fas fa-key me-2"></span>Reset password
                        </button>
                    </div>
                </div>
            </div>

        </div>

        <div class="row g-5">
            <div class="col-12 col-xxl-4">
                <?php while ($row = mysqli_fetch_assoc($query_results)) : ?>
                    <div class="row g-3 g-xxl-0 h-100">
                        <div class="col-12 col-md-7 col-xxl-12 mb-xxl-3">
                            <div class="card h-100">
                                <div class="card-body d-flex flex-column justify-content-between pb-3">
                                    <div class="row align-items-center g-5 mb-3 text-center text-sm-start">
                                        <div class="col-12 col-sm-auto mb-sm-2">
                                            <div class="avatar avatar-5xl"><img class="rounded-circle" src="../../assets/img/blank_profile.png" alt=""></div>
                                        </div>
                                        <div class="col-12 col-sm-auto flex-1">
                                            <h3><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></h3>
                                            <p class="text-800"><?php echo $row['about_patient']; ?></p>
                                            <div>
                                                <a class="me-2" href="#!">
                                                    <span class="fab fa-linkedin-in text-400 hover-primary"></span>
                                                </a>
                                                <a class="me-2" href="#!">
                                                    <span class="fab fa-facebook text-400 hover-primary"></span>
                                                </a>
                                                <a href="#!">
                                                    <span class="fab fa-twitter text-400 hover-primary"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-5 col-xxl-12 mb-xxl-3">
                            <div class="card h-100">
                                <div class="card-body pb-3">
                                    <div class="d-flex align-items-center mb-3">
                                        <h3 class="me-1">Default Address</h3>
                                    </div>
                                    <h5 class="text-800">Address</h5>
                                    <p class="text-800"><?php echo $row['street_name_add']; ?><br><?php echo $row['suburb_name']; ?><br>South Africa</p>
                                    <div class="mb-3">
                                        <h5 class="text-800">Email</h5><a href="mailto:<?php echo $row['email_address']; ?>"><?php echo $row['email_address']; ?></a>
                                    </div>
                                    <h5 class="text-800 mb-3">Phone</h5><a class="text-800" href="tel:<?php echo $row['contact_no']; ?>"><?php echo $row['contact_no']; ?></a>
                                    <hr>
                                    <h5 class="text-800 mb-1">Emergency Contact Person: </h5><a class="text-800 mb-3"><?php echo $row['ec_person']; ?></a>
                                    <h5 class="text-800 mb-1">Emergency Contact Person Number</h5><a class="text-800 mb-3" href="tel:<?php echo $row['ecp_number']; ?>"><?php echo $row['ecp_number']; ?></a>
                                </div>
                            </div>
                        </div>

                    </div>

            </div>
            <div class="col-12 col-xxl-8">
                <div class="card h-100">
                    <div class="card-body">
                        <form id="patient_profile_form" method="POST" action="manage_patient.php">
                            <div class="row gutters">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                                    <div class="alert alert-danger hide" id="alert_error" role="alert">One or more fields are empty</div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                                    <h6 class="mb-2 text-primary">Personal Details</h6>
                                </div>

                                <input type="hidden" class="form-control" id="user_ID" name="user_ID" value="<?php echo $user_ID; ?>">
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="first_name">First Name</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name" value="<?php echo $row['first_name']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="last_name">Last Name</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter last name" value="<?php echo $row['last_name']; ?>">
                                    </div>
                                </div>

                                <!--these will need to update the user table-->
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="email_address">Email</label>
                                        <input type="email" class="form-control" id="email_address" name="email_address" placeholder="Enter email ID" value="<?php echo $row['email_address']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="contact_no">Phone</label>
                                        <input type="text" class="form-control" id="contact_no" name="contact_no" placeholder="Enter phone number" value="<?php echo $row['contact_no']; ?>">
                                    </div>
                                </div>
                                <!--these will need to update the user table-->

                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="id_number">ID Number</label>
                                        <input type="number" class="form-control" id="id_number" name="id_number" placeholder="Enter ID number" onchange="autofillDOB()" value="<?php echo $row['id_number']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="dob">DOB</label>
                                        <input type="date" class="form-control" id="dob" name="dob" placeholder="Enter phone number" value="" value="<?php echo $row['dob']; ?>">
                                    </div>
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="gender">Gender</label>
                                        <select class="form-select" aria-label="Default select example" name="gender" id="gender" value="<?php echo $row['gender']; ?>">
                                            <option selected="">Select Gender</option>
                                            <option value="M">Male</option>
                                            <option value="F">Female</option>

                                        </select>


                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="profile_picture">Profile Picture</label>
                                        <input type="file" class="form-control" id="profile_picture" name="profile_picture" placeholder="Enter phone number" value="">
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="about_patient">Short Bio <span id="count_car">(100)</span></label>
                                        <input type="text" class="form-control" id="about_patient" name="about_patient" placeholder="Maximum of 100 Characters" value="<?php echo $row['about_patient']; ?>">
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                                    <h6 class="mb-2 text-primary">Address Details</h6>
                                </div>

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="street_name_add">Street Address</label>
                                        <input type="text" class="form-control" id="street_name_add" name="street_name_add" placeholder="Enter street name & house no" value="<?php echo $row['street_name_add']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="city_ID">City</label>

                                        <select class="form-select" aria-label="Default select example" name="city_ID" id="city_ID">
                                            <option selected="">Select your city</option>
                                            <option value="1">Port Elizabeth</option>
                                            <option value="2">Durban</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="suburb_ID">Suburb</label>

                                        <select class="form-select" aria-label="Default select example" name="suburb_ID" id="suburb_ID">
                                            <option selected="">Select your suburb</option>
                                            <option value="4">Bridgemead</option>
                                            <option value="5">Humewood</option>
                                            <option value="6">Algoa Park</option>
                                            <option value="7">Cotswold</option>
                                            <option value="8">Glenmore </option>
                                            <option value="9">Lorraine</option>
                                            <option value="10">Kwamashu </option>
                                            <option value="11">Inanda</option>
                                            <option value="12">Struandale </option>
                                            <option value="13">Tongaat</option>
                                            <option value="14">Walmer </option>
                                            <option value="15">Malabar</option>
                                            <option value="16">Summerstrand </option>
                                            <option value="17">Summerwood</option>
                                            <option value="18">Charlo </option>
                                            <option value="19">South End</option>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                                    <h6 class="mb-2 text-primary">Emergency Information</h6>
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="ec_person">Emergency Person Name</label>
                                        <input type="text" class="form-control" id="ec_person" name="ec_person" placeholder="Enter their name" value="<?php echo $row['ec_person']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="ecp_number">Emergency Person Number</label>
                                        <input type="number" class="form-control" id="ecp_number" name="ecp_number" placeholder="Enter their number" value="<?php echo $row['ecp_number']; ?>">
                                    </div>
                                </div>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                                    <h6 class="mb-2 text-primary">Social Information</h6>
                                </div>

                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="fb_link">Facebook Link</label>
                                        <input type="text" class="form-control" id="fb_link" name="fb_link" placeholder="Your facebook profile url" value="<?php echo $row['fb_link']; ?>">
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 mb-3">
                                    <div class="form-group">
                                        <label for="insta_link">Instagram Link</label>
                                        <input type="text" class="form-control" id="insta_link" name="insta_link" placeholder="Your Instagram profile url" value="<?php echo $row['insta_link']; ?>">
                                    </div>
                                </div>




                            </div>
                            <div class="row gutters">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="text-right">
                                        <button type="submit" id="submit" name="submit" class="btn btn-secondary">Cancel</button>
                                        <button type="submit" id="update_patient_profile" name="update_patient_profile" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }

    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;


        // Set the character count in the span

        //countElement.textContent = `(${100 - currentLength})`;

        // You can add additional logic here, such as disabling the input when it reaches the maximum length.
        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }

        // Set the character count in the span
        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<script>
    // Add an event listener to the "City" dropdown
    /* $('#city_name').change(function() {
        var selectedCity = $(this).val();

        // Hide all options in the "Suburb" dropdown
        $('#suburb_ID option').hide();

        // Show only the options that belong to the selected city
        $('#suburb_ID option[data-city="' + selectedCity + '"]').show();

        // Select the default option
        $('#suburb_ID').val('');
    }); */
</script>

<!-- <script>
    $('#add_cities').on('shown.bs.modal', function() {
        $('#myInput').trigger('focus')
    })
</script> -->

<?php
include("../../includes/footer.php");
?>