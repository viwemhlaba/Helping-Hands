<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");


// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];

$query = "SELECT * FROM patient_profile WHERE user_ID = '$user_ID'";
$results = mysqli_query($conn, $query);

if ($results) {
    $row = mysqli_fetch_assoc($results);
    $patientID = $row['patient_ID'];
} else {
    echo "Error executing the query: " . mysqli_error($conn);
}


if (isset($_GET['message'])) {
    if ($_GET['message'] === 'true') {
        $alertMessage = '<div class="alert alert-outline-success d-flex align-items-center" role="alert">
        <span class="fas fa-info-circle text-success fs-3 me-3"></span>
        <p class="mb-0 flex-1">You have successfully added the condition to your list of conditions
        </p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    } else {
        $alertMessage = '<div class="alert alert-outline-danger d-flex align-items-center" role="alert">
        <span class="fas fa-info-circle text-danger fs-3 me-3"></span>
        <p class="mb-0 flex-1">A simple primary alert—check it out!</p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
}
?>
<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage;
                ?>
            </div>
        <?php } ?>
    </div>
    <div class="mb-9">
        <div class="row align-items-center justify-content-between g-3 mb-4">
            <div class="col-auto">
                <h2 class="mb-0">List of chronic conditions</h2>
            </div>
        </div>
        <hr>
        <div class="row g-4">
            <?php

            $queryCondition = "SELECT * FROM `condition`;";

            $queryCondition_res = mysqli_query($conn, $queryCondition);

            if ($queryCondition_res) {
                $conditionData = mysqli_fetch_all($queryCondition_res, MYSQLI_ASSOC);

                foreach ($conditionData as $condition) {
                    $conditionName = $condition['condition_name'];
                    $conditionDescription = $condition['condition_description'];

            ?>

                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="card text-white bg-primary">
                            <div class="card-body">
                                <h4 class="card-title text-white"><?php echo $conditionName; ?></h4>
                                <p class="card-text"><?php echo $conditionDescription; ?></p>
                                <a class="btn btn-primary" href="add_condition.php?condition_ID=<?php echo $condition['condition_ID']; ?>">Add Condition</a>
                            </div>
                        </div>
                    </div>


            <?php


                }
            }
            ?>
        </div>
        <hr>
        <div class="row g-4">
            <div class="row align-items-center justify-content-between g-3 mb-4">
                <div class="col-auto">
                    <h2 class="mb-0">My Chronic Conditions</h2>
                </div>
            </div>

            <?php

            $queryConditionM = "SELECT pcc.*, pp.patient_ID, cc.condition_name, cc.condition_description, cc.condition_ID FROM patient_chronic_conditions pcc INNER JOIN patient_profile pp ON pcc.patient_ID = pp.patient_ID INNER JOIN `condition` cc ON pcc.condition_ID = cc.condition_ID WHERE pcc.patient_ID = $patientID";

            $queryConditionM_res = mysqli_query($conn, $queryConditionM);

            if ($queryConditionM_res) {
                $conditionDataM = mysqli_fetch_all($queryConditionM_res, MYSQLI_ASSOC);

                foreach ($conditionDataM as $conditionM) {
                    $condition_Name = $conditionM['condition_name'];
                    $condition_Description = $conditionM['condition_description'];

            ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo $condition_Name; ?></h4>
                                <p class="card-text"><?php echo $condition_Description; ?></p>
                            </div>
                        </div>
                    </div>
            <?php

                }
            }
            ?>

        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }
    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;
        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }
        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<?php
include("../../includes/footer.php");
?>