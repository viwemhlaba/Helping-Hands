<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");

// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];

//NOW LET US SELECT THE PATIENT TABLE
$query = "SELECT * FROM patient_profile WHERE user_ID = '$user_ID'";
$results =  mysqli_query($conn, $query);
$data = mysqli_fetch_all($results, MYSQLI_ASSOC);
$patientIDcurrent = $data[0]['patient_ID'];

// 1. Retrieve the current CARE CONTRACT
$queryCareContract = "SELECT * FROM care_contract WHERE care_contract_status = 'A' AND patient_ID = $patientIDcurrent AND active_status = 'Y'";
$resultCareContract = mysqli_query($conn, $queryCareContract);

if ($resultCareContract && mysqli_num_rows($resultCareContract) > 0) {
    $currentCareContract = mysqli_fetch_assoc($resultCareContract);
    $currentContractNumber = $currentCareContract['contract_number'];
    $currentPatientID = $currentCareContract['patient_ID'];

    // 2. Retrieve past CARE VISIT details
    $queryCareVisits = "SELECT * FROM care_visit WHERE contract_number = $currentContractNumber AND patient_ID = $currentPatientID /* AND visit_date < CURDATE() */";
    $resultCareVisits = mysqli_query($conn, $queryCareVisits);
    $resultCareVisitsData = mysqli_fetch_all($resultCareVisits, MYSQLI_ASSOC);
    // Now, you can display the details of the current CARE CONTRACT and past CARE VISITS
?>
    <div class="content">
        <!-- Display the details of the current CARE CONTRACT here -->
        <div class="row">
            <?php if (isset($alertMessage)) { ?>
                <div class="col">
                    <?php echo $alertMessage; ?>

                </div>
            <?php } ?>

        </div>

        <div class="row align-items-center justify-content-between g-3 mb-4">
            <div class="col-auto">
                <h2 class="mb-0">Care Visits </h2>
            </div>
            <div class="col-auto">
                <button class="btn btn-phoenix-primary" data-bs-toggle="modal" data-bs-target="#add_care_contract">
                    <span class="fa-solid fa-plus me-2"></span> Create Care Visit
                </button>
            </div>
        </div>

        <div class="mx-n4 px-4 mx-lg-n6 px-lg-6 bg-white border-top border-bottom border-200 position-relative top-1">
            <div class="table-responsive scrollbar mx-n1 px-1">
                <table class="table table-sm fs--1 mb-0">
                    <thead>
                        <tr>
                            <th class="sort align-middle">Contract Number</th>
                            <th class="sort align-middle">Contract Start Date</th>
                            <th class="sort align-middle">Wound Description</th>
                            <th class="sort align-middle">Visit Notes</th>
                            <th class="sort align-middle">Visit Date</th>
                            <th class="sort align-middle">Visit Time</th>
                            <th class="sort align-middle">Depart Time</th>
                            <th class="sort align-middle">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($resultCareVisitsData as $resultCareVisitsData) {

                        ?>
                            <!--HTML OR MAIN TABLE HERE-->
                            <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['contract_number']) ? $resultCareVisitsData['contract_number'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['contract_date']) ? $resultCareVisitsData['contract_date'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['wound_progress']) ? $resultCareVisitsData['wound_progress'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['visit_notes']) ? $resultCareVisitsData['visit_notes'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['visit_date']) ? $resultCareVisitsData['visit_date'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['visit_time']) ? $resultCareVisitsData['visit_time'] : 'Not Set'; ?></td>

                                <td class="sort align-middle"><?php echo isset($resultCareVisitsData['depart_time']) ? $resultCareVisitsData['depart_time'] : 'Not Set'; ?></td>
                                <td class="sort align-middle">
                                    <a class="btn btn-primary" href="view_care_service.php?contract_number=<?php echo isset($resultCareVisitsData['contract_number']) ? $resultCareVisitsData['contract_number'] : 'Not Set'; ?>"><span class="fa-solid fa-pen-to-square"></span></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>

        </div>
        <!-- Display the details of past CARE VISITS here -->
    </div>
<?php
} else {
    echo "No current CARE CONTRACT found.";
}

include("../../includes/footer.php");
?>