<?php
session_start();
ob_start(); // Start output buffering
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");
// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}
// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

$nurse_ID = $_GET['nurse_ID'];
$contract_number = $_GET['contract_number'];
$patient_ID = $_GET['patient_ID'];

if(isset($_POST['add_care_visit'])){
    $nurse_ID = $_POST['nurse_ID'];
    $contract_number = $_POST['contract_number'];
    $patient_ID = $_POST['patient_ID'];
    $wound_progress = $_POST['wound_progress'];
    $visit_date = $_POST['visit_date'];
    $visit_notes = $_POST['visit_notes'];
    $appro_visit_time = $_POST['appro_visit_time'];
    $status =  "A";

    $query = "INSERT INTO `care_visit` (nurse_ID, contract_number, patient_ID, wound_progress, visit_notes, appro_visit_time, status) VALUES ('$nurse_ID', '$contract_number', '$patient_ID', '$wound_progress', '$visit_notes', '$appro_visit_time', '$status')";
    $results = mysqli_query($conn, $query);

    if($results){
        header("Location: /Helping-Hands/src/users/Nurse/care_visits_assigned.php?nurse_ID=$nurse_ID&contract_number=$contract_number&patient_ID=$patient_ID&status_schedule=yes");

        ob_end_flush(); // End and flush the output buffer
        exit();
    }
    
}
?>
<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>
            </div>
        <?php } ?>
    </div>
    <h2 class="mb-4">Create a visit Plan</h2>
    <hr>
    <div class="row">
        <div class="col-xl-9">
            <form class="row g-3 mb-6" action="" method="POST">
                <input type="hidden" name="nurse_ID" id="nurse_ID" class="form-control error_input" value="<?php echo $nurse_ID; ?>">
                <input type="hidden" name="contract_number" id="contract_number" class="form-control error_input" value="<?php echo $contract_number; ?>">
                <input type="hidden" name="patient_ID" id="patient_ID" class="form-control error_input" value="<?php echo $patient_ID; ?>">
                <div class="col-sm-6 col-md-8">
                    <div class="form-floating"><input class="form-control" id="wound_progress" name="wound_progress" type="text" placeholder="Please describe the wound in details"><label for="wound_progress">Wound Progress</label></div>
                </div>
                <div class="col-sm-6 col-md-8">
                    <div class="form-floating"><input class="form-control" id="visit_notes" name="visit_notes" type="text" placeholder="Please describe the wound in details"><label for="visit_notes">Visit Notes</label></div>
                </div>
                <div class="col-sm-6 col-md-8">
                    <label for="visit_date" class="form-label form_label">Set Visit Date</label>
                    <input type="date" class="form-control" id="visit_date" name="visit_date" placeholder="Enter phone number" value="" style="padding: 15px;">
                </div>
                <div class="col-sm-6 col-md-8">
                    <label for="appro_visit_time" class="form-label form_label">Set Approximate Visit Time</label>
                    <input type="time" class="form-control" id="appro_visit_time" name="appro_visit_time" value="" style="padding: 15px;">
                </div>
                <div class="col-sm-6 col-md-8">
                    <button type="submit" name="add_care_visit" id="add_care_visit" class="btn btn-primary w-100 mb-0">Create a visit Plan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
include("../../includes/footer.php");
?>





<?php
// Assuming a function named update_profile is defined
$result = update_profile(
    $conn,
    $user_ID,
    $email_address,
    $contact_no,
    $first_name,
    $last_name,
    $id_number,
    $dob,
    $profile_picture,
    $about_patient,
    $street_name_add,
    $suburb_ID,
    $ec_person,
    $ecp_number,
    $fb_link,
    $insta_link
);

// Definition of update_profile function
function update_profile($conn, $user_ID, $email_address, $contact_no, $first_name, $last_name, $id_number, 
$dob, $profile_picture, $about_patient, $street_name_add, $suburb_ID, $ec_person, $ecp_number, $fb_link, $insta_link) {
    // Create a prepared statement for user table update
    $update_user_table_query = "UPDATE user SET email_address = ?, contact_no = ? WHERE user_ID = ?";
    $stmt_user = mysqli_prepare($conn, $update_user_table_query);

    if (!$stmt_user) {
        return 'Error creating prepared statement for user table';
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt_user, "ssi", $email_address, $contact_no, $user_ID);

    // Execute the statement for user table
    if (!mysqli_stmt_execute($stmt_user)) {
        return 'Error updating user table';
    }

    // Close the statement for user table
    mysqli_stmt_close($stmt_user);

    // Create a prepared statement for patient_profile update
    $update_patient_profile_table_query = "UPDATE patient_profile SET first_name = ?, last_name = ?, 
    id_number = ?, dob = ?, profile_picture = ?, about_patient = ?, street_name_add = ?, suburb_ID = ?, ec_person = ?, 
    ecp_number = ?, fb_link = ?, insta_link = ? WHERE user_ID = ?";
    $stmt_patient_profile = mysqli_prepare($conn, $update_patient_profile_table_query);

    if (!$stmt_patient_profile) {
        return 'Error creating prepared statement for patient_profile table';
    }

    // Bind parameters for patient_profile
    mysqli_stmt_bind_param($stmt_patient_profile, "ssissssisissi", $first_name, $last_name, $id_number, 
    $dob, $profile_picture, $about_patient, $street_name_add, $suburb_ID, $ec_person, 
    $ecp_number, $fb_link, $insta_link, $user_ID);

    // Execute the statement for patient_profile
    if (!mysqli_stmt_execute($stmt_patient_profile)) {
        return 'Error updating patient_profile table';
    }

    // Close the statement for patient_profile
    mysqli_stmt_close($stmt_patient_profile);

    return 'Profile updated successfully';
}

?>