<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

// Your HTML and other content for the Admin dashboard
include("../../database/db.php");
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");



$alertMessage = '';

if (isset($_GET['admin_dashboard']) && $_GET['admin_dashboard'] == 'city_empty') {
    $alertMessage = '
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error!</strong> The City Name and Abbreviation can not be empty.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
  ';
} else if (isset($_GET['admin_dashboard']) && $_GET['admin_dashboard'] == 'city_added') {
    $alertMessage = '
  <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Congratulations!</strong> The City Name and Abbreviation have been added to database.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
  ';
}


$query = "SELECT pp.last_name, pp.first_name, pp.status, pp.user_ID, user.email_address, user.contact_no, user.user_ID
FROM patient_profile pp
INNER JOIN user user ON pp.user_ID = user.user_ID
WHERE pp.status = 'A'";

$result = mysqli_query($conn, $query);
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);



//calling the method to insert
/* $user_ID_NEW = $user_ID;
$query = "CALL GetPatientProfileInfo($user_ID_NEW)";

$query_results = mysqli_query($conn, $query);
if (!$query_results) {
    die("Error: " . mysqli_error($conn));
    exit();
} */




if(isset($_GET['deleteStatus'])){
    $alertMessage = '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Congratulations!</strong> You have successfully deleted your prefered suburb
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    ';
}


?>
<style>
.suburb-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.suburb-row span {
    flex: 1;
    padding-right: 10px;
}
</style>

<!--add subs modal-->
<div id="add_subs" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Prefered</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="main_form" action="nurse_dashboard.php" method="POST">
                    <div class="mb-3">
                        <label for="city_abr" class="form-label form_label">Where do you want the contract to be?</label>
                        <select type="number" name="city_ID" id="city_ID" class="form-control error_input">
                            <option selected>Open this select menu</option>
                            <?php

                            @include '../../database/db.php';

                            $results = mysqli_query($conn, "SELECT `city_ID`,`city_name` FROM `city`");

                            while ($data = mysqli_fetch_array($results)) {
                                echo "<option value='" . $data['city_ID'] . "'>" . $data['city_name'] . "</option>";
                            }

                            ?>
                        </select>
                        <span id="error_city_ID" class="error"></span>
                    </div>

                    <div class="mb-3">
                        <label for="suburb_ID" class="form-label form_label">Where do you want the contract to be?</label>
                        <select type="number" name="suburb_ID" id="suburb_ID" class="form-control error_input">
                            <option selected>Open this select menu</option>

                        </select>
                        <span id="error_city_ID" class="error"></span>
                    </div>
                    <div><button type="submit" name="prefered_sub" id="prefered_sub" class="btn btn-primary w-100 mb-0">Save Changes</button></div>
                </form>
            </div>
        </div>

    </div>
</div>
<!--modals here-->

<!--add subs modal-->
<div id="add_subs_delete" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Your prefered suburbs</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
                    $query_list_of_prefered_suburbs = "SELECT pp.*, su.* FROM prefered_nurse_suburb pp JOIN suburb su ON pp.suburb_ID = su.suburb_ID WHERE user_ID = '$user_ID'";
                    $result_query_list_of_prefered_suburbs = mysqli_query($conn, $query_list_of_prefered_suburbs);
                    $data = mysqli_fetch_all($result_query_list_of_prefered_suburbs, MYSQLI_ASSOC);

                    foreach ($data as $row){
                        echo '<p class="suburb-row"><span>' . $row['suburb_name'] . '</span><a href="delete_preferred_suburb.php/?prefered_nurse_suburb_ID='.$row['prefered_nurse_suburb_ID'].'" data-id="' . $row['prefered_nurse_suburb_ID'] . '" class="delete-suburb"><i class="fa fa-trash"></i> Delete</a></p>';
                    }
                ?>
            </div>
        </div>

    </div>
</div>
<!--modals here-->

<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage ?>
            </div>
        <?php } ?>

    </div>

    <div class="row gy-3 mb-6 justify-content-between">
        <div class="col-md-8 col-auto">
            <h2 class="mb-2 text-1100">Nurse Dashboard</h2>
            <h5 class="text-700 fw-semi-bold">This is a summary of the entire system</h5>
        </div>

        
    </div>
    <hr>
    <div class="row g-3 mb-5">
        <div class="col-md-6 col-xxl-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <div>
                            <h5 class="mb-1">Total orders<span class="badge badge-phoenix badge-phoenix-warning rounded-pill fs--1 ms-2"><span class="badge-label">-6.8%</span></span></h5>
                            <h6 class="text-700">Last 7 days</h6>
                        </div>

                    </div>
                    <div class="d-flex justify-content-center px-4 py-6">
                        <div class="echart-total-orders" style="height: 85px; width: 115px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative;" _echarts_instance_="ec_1693841931602">
                            <div style="position: relative; width: 115px; height: 85px; padding: 0px; margin: 0px; border-width: 0px;"><canvas data-zr-dom-id="zr_0" width="115" height="85" style="position: absolute; left: 0px; top: 0px; width: 115px; height: 85px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas></div>
                            <div class=""></div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <h4>16,247 Active Contracts</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xxl-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <div>
                            <h5 class="mb-1">Total orders<span class="badge badge-phoenix badge-phoenix-warning rounded-pill fs--1 ms-2"><span class="badge-label">-6.8%</span></span></h5>
                            <h6 class="text-700">Last 7 days</h6>
                        </div>

                    </div>
                    <div class="d-flex justify-content-center px-4 py-6">
                        <div class="echart-total-orders" style="height: 85px; width: 115px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative;" _echarts_instance_="ec_1693841931602">
                            <div style="position: relative; width: 115px; height: 85px; padding: 0px; margin: 0px; border-width: 0px;"><canvas data-zr-dom-id="zr_0" width="115" height="85" style="position: absolute; left: 0px; top: 0px; width: 115px; height: 85px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas></div>
                            <div class=""></div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <h4>16,247 Active Contracts</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xxl-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <div>
                            <h5 class="mb-1">Total orders<span class="badge badge-phoenix badge-phoenix-warning rounded-pill fs--1 ms-2"><span class="badge-label">-6.8%</span></span></h5>
                            <h6 class="text-700">Last 7 days</h6>
                        </div>

                    </div>
                    <div class="d-flex justify-content-center px-4 py-6">
                        <div class="echart-total-orders" style="height: 85px; width: 115px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative;" _echarts_instance_="ec_1693841931602">
                            <div style="position: relative; width: 115px; height: 85px; padding: 0px; margin: 0px; border-width: 0px;"><canvas data-zr-dom-id="zr_0" width="115" height="85" style="position: absolute; left: 0px; top: 0px; width: 115px; height: 85px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas></div>
                            <div class=""></div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <h4>16,247 Active Contracts</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xxl-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <div>
                            <h5 class="mb-1">Total orders<span class="badge badge-phoenix badge-phoenix-warning rounded-pill fs--1 ms-2"><span class="badge-label">-6.8%</span></span></h5>
                            <h6 class="text-700">Last 7 days</h6>
                        </div>

                    </div>
                    <div class="d-flex justify-content-center px-4 py-6">
                        <div class="echart-total-orders" style="height: 85px; width: 115px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative;" _echarts_instance_="ec_1693841931602">
                            <div style="position: relative; width: 115px; height: 85px; padding: 0px; margin: 0px; border-width: 0px;"><canvas data-zr-dom-id="zr_0" width="115" height="85" style="position: absolute; left: 0px; top: 0px; width: 115px; height: 85px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas></div>
                            <div class=""></div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <h4>16,247 Active Contracts</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-5 justify-content-between">
        <div class="col-md-6 col-auto">

            <div class="card p-3">
                <div class="card-body">
                    <h5 class="card-title">List of patients - <span class="fw-light">this will show a list of active patients</span></h5>
                    <hr>
                    <div class="table-responsive scrollbar">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">First</th>
                                    <th scope="col">Last</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Number</th>

                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <th scope="row">1</th>
                                    <td>Carlos</td>
                                    <td>Andrade</td>
                                    <td>carlosA@gmail.com</td>
                                    <td>0682581235</td>
                                </tr>

                                <tr>
                                    <th scope="row">1</th>
                                    <td>Kabelo</td>
                                    <td>Padi</td>
                                    <td>kabeloP@gmail.com</td>
                                    <td>0742458796</td>
                                </tr>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-md-6 col-auto">

            <div class="card p-3">
                <div class="card-body">
                    <h5 class="card-title">List of nurse - <span class="fw-light">this will show a list of active patients</span></h5>
                    <hr>
                    <div class="table-responsive scrollbar">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">First</th>
                                    <th scope="col">Last</th>
                                    <th scope="col">Code</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Number</th>

                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <th scope="row">1</th>
                                    <td>Dorothy</td>
                                    <td>Daniels</td>
                                    <td>Nurse_202322</td>
                                    <td>dorothy@gmail.com</td>
                                    <td>0849095263</td>
                                </tr>

                                <tr>
                                    <th scope="row">1</th>
                                    <td>Lesedi</td>
                                    <td>Moloi</td>
                                    <td>Nurse_202325</td>
                                    <td>Lesedi@gmail.com</td>
                                    <td>0798549874</td>
                                </tr>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }

    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;


        // Set the character count in the span

        //countElement.textContent = `(${100 - currentLength})`;

        // You can add additional logic here, such as disabling the input when it reaches the maximum length.
        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }

        // Set the character count in the span
        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<!-- <script>
    // Add an event listener to the "City" dropdown
    $('#city_ID').change(function() {
        var selectedCity = $(this).val();

        // Hide all options in the "Suburb" dropdown
        $('#suburb_ID option').hide();

        // Show only the options that belong to the selected city
        $('#suburb_ID option[data-city="' + selectedCity + '"]').show();

        // Select the default option
        $('#suburb_ID').val('');
    });
</script> -->
<script>
    document.getElementById("city_ID").addEventListener("change", function() {
        // Get the selected city_ID
        var selectedCity = this.value;

        // Use AJAX to send a request to the server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_suburbs_ajax_call.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response and populate the suburb dropdown
                var suburbs = JSON.parse(xhr.responseText);
                var suburbDropdown = document.getElementById("suburb_ID");
                suburbDropdown.innerHTML = "<option selected>Select a suburb</option>";

                suburbs.forEach(function(suburb) {
                    var option = document.createElement("option");
                    option.value = suburb.suburb_ID;
                    option.textContent = suburb.suburb_name;
                    suburbDropdown.appendChild(option);
                });
            }
        };

        // Send the request with the selected city
        xhr.send("city_ID=" + selectedCity);
    });
</script>

<?php
include("../../includes/footer.php");
?>