<?php
// Include your database connection
@include '../../database/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the selected city_ID from the POST data
    $selectedCity = $_POST["city_ID"];

    // Query the database for suburbs associated with the selected city
    $query = "SELECT suburb_ID, suburb_name FROM suburb WHERE city_ID = " . $selectedCity;
    $results = mysqli_query($conn, $query);

    if ($results) {
        $suburbs = mysqli_fetch_all($results, MYSQLI_ASSOC);

        // Return the suburb data as JSON
        echo json_encode($suburbs);
    }
}
