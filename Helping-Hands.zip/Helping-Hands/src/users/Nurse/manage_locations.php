<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");


// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

$query = "SELECT pp.*, user.*, suburb.* FROM prefered_nurse_suburb pp 
INNER JOIN user user ON pp.user_ID = user.user_ID
INNER JOIN suburb suburb ON pp.suburb_ID = suburb.suburb_ID
WHERE pp.user_ID = '$user_ID';";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Error: " . mysqli_error($conn));
    exit();
}
$result_data = mysqli_fetch_all($result, MYSQLI_ASSOC);

if (isset($_GET['deleteStatus'])) {
    $alertMessage = '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Congratulations!</strong> You have successfully deleted your prefered suburb
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    ';
}

if (isset($_POST['prefered_sub'])) {
    $suburb_ID = $_POST['suburb_ID'];

    $query_add_prefered_sub = "INSERT INTO prefered_nurse_suburb (user_ID, suburb_ID)
    VALUES ($user_ID, $suburb_ID);";
    $query_add_prefered_sub_result = mysqli_query($conn, $query_add_prefered_sub);

    if ($query_add_prefered_sub_result) {
        $alertMessage = '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Congratulations!</strong> You have successfully deleted your prefered suburb
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    ';
    } else {
        echo 'Not Successfully Added';
    }
}
?>
<!--modals here-->
<!--add subs modal-->
<div id="add_subs" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Prefered</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="main_form" action="" method="POST">
                    <div class="mb-3">
                        <label for="city_abr" class="form-label form_label">Where do you want the contract to be?</label>
                        <select type="number" name="city_ID" id="city_ID" class="form-control error_input">
                            <option selected>Open this select menu</option>
                            <?php

                            @include '../../database/db.php';

                            $results = mysqli_query($conn, "SELECT `city_ID`,`city_name` FROM `city`");

                            while ($data = mysqli_fetch_array($results)) {
                                echo "<option value='" . $data['city_ID'] . "'>" . $data['city_name'] . "</option>";
                            }

                            ?>
                        </select>
                        <span id="error_city_ID" class="error"></span>
                    </div>

                    <div class="mb-3">
                        <label for="suburb_ID" class="form-label form_label">Where do you want the contract to be?</label>
                        <select type="number" name="suburb_ID" id="suburb_ID" class="form-control error_input">
                            <option selected>Open this select menu</option>

                        </select>
                        <span id="error_city_ID" class="error"></span>
                    </div>
                    <div><button type="submit" name="prefered_sub" id="prefered_sub" class="btn btn-primary w-100 mb-0">Save Changes</button></div>
                </form>
            </div>
        </div>

    </div>
</div>
<!--modals here-->


<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage ?>
            </div>
        <?php } ?>

    </div>

    <div class="mb-9">
        <div class="row align-items-center justify-content-between g-3 mb-4">

            <div class="col-auto">
                <h2 class="mb-0">Prefered Locations</h2>
                <p>This is a list of all prefered locations by the nurse</p>
            </div>

            <div class="col-auto">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#add_subs">
                    Add Your Location
                </button>

            </div>
        </div>

        <div class="row g-4">
            <?php
            foreach ($result_data as $row) {
            ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <h4 class="card-title text-white"><?php echo $row['suburb_name'] ?></h4>
                            <p class="card-text">Postal Code: <span style="font-weight: 700;"><?php echo $row['postal_code'] ?></span></p>

                            <a class="btn btn-danger" href="delete_preferred_suburb.php?prefered_nurse_suburb_ID=<?php echo $row['prefered_nurse_suburb_ID']; ?>" data-id="<?php echo $row['prefered_nurse_suburb_ID']; ?>">Remove Location</a>

                        </div>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }

    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;


        // Set the character count in the span

        //countElement.textContent = `(${100 - currentLength})`;

        // You can add additional logic here, such as disabling the input when it reaches the maximum length.
        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }

        // Set the character count in the span
        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<!-- <script>
    // Add an event listener to the "City" dropdown
    $('#city_ID').change(function() {
        var selectedCity = $(this).val();

        // Hide all options in the "Suburb" dropdown
        $('#suburb_ID option').hide();

        // Show only the options that belong to the selected city
        $('#suburb_ID option[data-city="' + selectedCity + '"]').show();

        // Select the default option
        $('#suburb_ID').val('');
    });
</script> -->
<script>
    document.getElementById("city_ID").addEventListener("change", function() {
        // Get the selected city_ID
        var selectedCity = this.value;

        // Use AJAX to send a request to the server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_suburbs_ajax_call.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response and populate the suburb dropdown
                var suburbs = JSON.parse(xhr.responseText);
                var suburbDropdown = document.getElementById("suburb_ID");
                suburbDropdown.innerHTML = "<option selected>Select a suburb</option>";

                suburbs.forEach(function(suburb) {
                    var option = document.createElement("option");
                    option.value = suburb.suburb_ID;
                    option.textContent = suburb.suburb_name;
                    suburbDropdown.appendChild(option);
                });
            }
        };

        // Send the request with the selected city
        xhr.send("city_ID=" + selectedCity);
    });
</script>

<?php
include("../../includes/footer.php");
?>