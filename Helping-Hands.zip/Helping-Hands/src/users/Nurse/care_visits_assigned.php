<?php
session_start();
ob_start(); // Start output buffering
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");
// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}
// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

if (isset($_GET['nurse_ID']) && isset($_GET['contract_number']) && isset($_GET['patient_ID'])) {
    $nurse_ID = $_GET['nurse_ID'];
    $contract_number = $_GET['contract_number'];
    $patient_ID = $_GET['patient_ID'];
}

if (isset($_GET['status_schedule'])) {
    $alertMessage = '<div class="alert alert-success" id="alert_error" role="alert">You have successfully created a care visit yourself in the contract</div>';
}

$query = "SELECT cv.*, cc.*, pp.patient_ID, pp.first_name AS patient_name, pp.last_name AS patient_lastname, np.*
FROM care_visit cv
INNER JOIN care_contract cc ON cv.contract_number = cc.contract_number
INNER JOIN patient_profile pp ON cv.patient_ID = pp.patient_ID
INNER JOIN nurse_profile np ON cv.nurse_ID = np.nurse_ID
WHERE cv.nurse_ID = '$nurse_ID' AND cc.contract_number = '$contract_number'";
$query_results = mysqli_query($conn, $query);

if (!$query_results) {
    // Query execution failed
    die("Error: " . mysqli_error($conn));
} else {
    // Query was successful, proceed to fetch the results
    $query_resultsData = mysqli_fetch_all($query_results, MYSQLI_ASSOC);
}



?>
<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>
            </div>
        <?php } ?>
    </div>

    <div class="row align-items-center justify-content-between g-3 mb-4">
        <div class="col-auto">
            <h2 class="mb-0">Care Visits </h2>
        </div>
        <div class="col-auto">
            <div class="dropdown font-sans-serif d-inline-block">
                <button class="btn btn-phoenix-secondary dropdown-toggle" id="dropdownMenuButton" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Filter the table</button><span class="caret"> </span>
                <div class="dropdown-menu dropdown-menu-end py-0" aria-labelledby="dropdownMenuButton" style="">
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Patient/manage_care_contract.php/?status=N">New Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Patient/manage_care_contract.php/?status=A">Active Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Patient/manage_care_contract.php/?status=C">Closed Contracts</a>
                </div>
            </div>
            <button class="btn btn-phoenix-primary" data-bs-toggle="modal" data-bs-target="#add_care_contract">
                <span class="fa-solid fa-plus me-2"></span> Create Care Contract
            </button>
        </div>
    </div>

    <div class="mx-n4 px-4 mx-lg-n6 px-lg-6 bg-white border-top border-bottom border-200 position-relative top-1">
        <div class="table-responsive scrollbar mx-n1 px-1">
            <table class="table table-sm fs--1 mb-0">
                <thead>
                    <tr>
                        <th class="sort align-middle">#</th>
                        <th class="sort align-middle">Patient</th>
                        <th class="sort align-middle">Nurse</th>
                        <th class="sort align-middle">Wound progress</th>
                        <th class="sort align-middle">Visit Notes</th>
                        <th class="sort align-middle">Visit Date</th>
                        <th class="sort align-middle">Visit Time</th>
                        <th class="sort align-middle">Depart Time</th>

                        <th class="sort align-middle">Action</th>
                    </tr>
                </thead>
                <tbody class="list" id="order-table-body">
                    <?php
                    foreach ($query_resultsData as $row) {
                    ?>
                        <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                            <td class="sort align-middle fw-bold"><?php echo isset($row['contract_number']) ? $row['contract_number'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['patient_name']) ? $row['patient_name'] : 'Not Set'; ?> <?php echo isset($row['patient_lastname']) ? $row['patient_lastname'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['first_name']) ? $row['first_name'] : 'Not Set'; ?> <?php echo isset($row['last_name']) ? $row['last_name'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['wound_progress']) ? $row['wound_progress'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['visit_notes']) ? $row['visit_notes'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['visit_date']) ? $row['visit_date'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['appro_visit_time']) ? $row['appro_visit_time'] : 'Not Set'; ?></td>
                            <td class="sort align-middle"><?php echo isset($row['depart_time']) ? $row['depart_time'] : 'Not Set'; ?></td>
                            <td class="sort align-middle">
                                <a type="submit" class="btn btn-phoenix-warning" name="view_care_contract" id="view_care_contract" href="/Helping-Hands/src/users/Nurse/update_care_visit.php?care_visit_ID=<?php echo $row['care_visit_ID']?>">
                                    Update Visit
                                    </a>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
include("../../includes/footer.php");
?>