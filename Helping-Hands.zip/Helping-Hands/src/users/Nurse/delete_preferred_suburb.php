<?php
session_start();
include("../../database/db.php");

if (!isset($_SESSION['user_ID'])) {
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

if (isset($_GET['prefered_nurse_suburb_ID'])) {
    // Sanitize the input to prevent SQL injection
    $prefered_nurse_suburb_ID =  $_GET['prefered_nurse_suburb_ID'];

    // Check if the user is authorized to delete this suburb, e.g., make sure it belongs to the user
    // You should have additional authorization logic here

    // Perform the delete operation
    $delete_query = "DELETE FROM prefered_nurse_suburb WHERE prefered_nurse_suburb_ID = '$prefered_nurse_suburb_ID'";
    $result = mysqli_query($conn, $delete_query);

    if ($result) {
        // Suburb deleted successfully
        header("Location: /Helping-Hands/src/users/Nurse/manage_locations.php?deleteStatus=yes"); // Redirect to a suitable page
        exit();
    } else {
        // Handle the error, e.g., display an error message
        header("Location: /Helping-Hands/src/users/Nurse/manage_locations.php?deleteStatus=no");
        echo "Error deleting the preferred suburb: " . mysqli_error($conn);
    }
} else {
    // Handle the case when prefered_nurse_suburb_ID is not provided in the URL
    echo "Invalid request.";
}
?>
