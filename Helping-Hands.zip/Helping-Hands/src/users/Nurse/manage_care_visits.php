<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");
// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}
// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

//check the parameters if they are set

if (isset($_GET['status'])) {
    $status = $_GET['status'];
} else {
    $status = "A";
}

$alertMessage = "";

$query = "SELECT * FROM nurse_profile WHERE user_ID = '$user_ID'";
$results =  mysqli_query($conn, $query);
$data = mysqli_fetch_all($results, MYSQLI_ASSOC);

foreach ($data as $row) {
    // Access the patient_ID for each row and add it to the $patientIDs array
    $nurse_ID = $row['nurse_ID'];
}

$query_list = "SELECT cc.*, pp.patient_ID, pp.first_name AS patientName, pp.last_name AS patientLastName, np.*
FROM care_contract cc

INNER JOIN patient_profile pp ON cc.patient_ID = pp.patient_ID
INNER JOIN nurse_profile np ON cc.nurse_ID = np.nurse_ID
WHERE np.nurse_ID = '$nurse_ID' AND cc.care_contract_status='$status';";
$results_list =  mysqli_query($conn, $query_list);
$careVisit_data = mysqli_fetch_all($results_list, MYSQLI_ASSOC);

//$today = date("Y-m-d");


if (isset($_GET['manage_care_contract']) && $_GET['manage_care_contract'] == 'success') {
    $alertMessage = '<div class="alert alert-success" id="alert_error" role="alert">Your care contract has been successfully created</div>';
}
?>

<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>

            </div>
        <?php } ?>

    </div>
    <div class="row align-items-center justify-content-between g-3 mb-4">
        <div class="col-auto">
            <h2 class="mb-0">Care Visits Schedule </h2>
            <p>You will be able to see all Care Visits Schedule</p>
        </div>
        <div class="col-auto">


            <div class="dropdown font-sans-serif d-inline-block">
                <button class="btn btn-phoenix-secondary dropdown-toggle" id="dropdownMenuButton" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Filter the table</button><span class="caret"> </span>
                <div class="dropdown-menu dropdown-menu-end py-0" aria-labelledby="dropdownMenuButton" style="">
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=N">New Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=A">Active Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=C">Closed Contracts</a>
                </div>
            </div>


        </div>
    </div>
    <div class="mx-n4 px-4 mx-lg-n6 px-lg-6 bg-white border-top border-bottom border-200 position-relative top-1">
        <div class="table-responsive scrollbar mx-n1 px-1">
            <table class="table table-sm fs--1 mb-0">
                <thead>
                    <tr>

                        <th class="sort align-middle">Responsible Nurse</th>
                        <th class="sort align-middle">Patient Information</th>
                        <th class="sort align-middle">Wound Description</th>

                        <th class="sort align-middle">Contract Start</th>
                        <th class="sort align-middle">Status</th>
                        <th class="sort align-middle">Action</th>
                    </tr>
                </thead>

                <tbody class="list" id="order-table-body">
                    <?php
                    foreach ($careVisit_data as $contactRow_main) {
                    ?>
                        <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                            <input type="hidden" name="nurse_ID" id="nurse_ID" class="form-control error_input" value="<?php echo isset($contactRow_main['nurse_ID']) ? $contactRow_main['nurse_ID'] : 'Not Set'; ?>">
                            <td class="sort align-middle fw-bold"><?php echo !empty($contactRow_main) ? $contactRow_main['first_name'] . ' ' . $contactRow_main['last_name'] : 'Not Assigned to Nurse'; ?></td>
                            <td class="sort align-middle"><?php echo !empty($contactRow_main) ? $contactRow_main['patientName'] . ' ' . $contactRow_main['patientLastName'] : 'Not Assigned to Nurse'; ?></td>
                            <td class="sort align-middle"><?php echo isset($contactRow_main['wound_description']) ? $contactRow_main['wound_description'] : '<span class="badge badge-phoenix badge-phoenix-danger">Not set yet</span>'; ?></td>
                            <td class="sort align-middle"><?php echo isset($contactRow_main['contract_date']) ? $contactRow_main['contract_date'] : 'Not Set'; ?></td>

                            <td class="sort align-middle">
                                <?php
                                if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'N') {
                                    echo '<span class="badge badge-phoenix badge-phoenix-warning">New Contract</span>';
                                } else if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'A') {
                                    echo '<span class="badge badge-phoenix badge-phoenix-success">Active Contract</span>';
                                } else if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'C') {
                                    echo '<span class="badge badge-phoenix badge-phoenix-danger">Closed Contract</span>';
                                }
                                ?>
                            </td>

                            <td class="sort align-middle">
                                <a type="submit" class="btn btn-phoenix-warning" name="view_care_contract" id="view_care_contract" href="/Helping-Hands/src/users/Nurse/assign_contract.php?nurse_ID='.$contactRow['nurse_ID'].'&contract_number='.$contactRow_main['contract_number'].'&contract_date='.$contactRow_main['contract_date'].'">
                                    View Care History
                                </a>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }
    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);
    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;

        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }

        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<script>
    document.getElementById("city_ID").addEventListener("change", function() {
        // Get the selected city_ID
        var selectedCity = this.value;

        // Use AJAX to send a request to the server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_suburbs_ajax_call.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response and populate the suburb dropdown
                var suburbs = JSON.parse(xhr.responseText);
                var suburbDropdown = document.getElementById("suburb_ID");
                suburbDropdown.innerHTML = "<option selected>Select a suburb</option>";
                suburbs.forEach(function(suburb) {
                    var option = document.createElement("option");
                    option.value = suburb.suburb_ID;
                    option.textContent = suburb.suburb_name;
                    suburbDropdown.appendChild(option);
                });
            }
        };
        xhr.send("city_ID=" + selectedCity);
    });
</script>
<?php
include("../../includes/footer.php");
?>