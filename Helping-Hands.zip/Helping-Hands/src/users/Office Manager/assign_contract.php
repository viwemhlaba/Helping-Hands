<?php
session_start();
ob_start(); // Start output buffering
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");
// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}
// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];
$nurse_ID = $_GET['nurse_ID'];
$contract_number = $_GET['contract_number'];
//process this 
if(isset($_POST['assign_nurse'])){
    $nurse_ID = $_POST['nurse_ID'];
    $contract_number = $_POST['contract_number'];
    $wound_description = $_POST['wound_description'];
    $care_start_date = $_POST['care_start_date'];
    $care_contract_status = "A";
    $active_status = "Y";
    $query = "UPDATE care_contract SET nurse_ID = '$nurse_ID', wound_description = '$wound_description', care_start_date = '$care_start_date', care_contract_status = '$care_contract_status', active_status = '$active_status' WHERE contract_number = '$contract_number'";
    $result = mysqli_query($conn, $query);
    if($result){
        header("Location: /Helping-Hands/src/users/Nurse/manage_contracts.php?assign_status=yes");
        ob_end_flush(); // End and flush the output buffer
        exit();
    }
}
?>
<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>
            </div>
        <?php } ?>
    </div>
    <h2 class="mb-4">Create a project</h2>
    <hr>
    <div class="row">
        <div class="col-xl-9">
            <form class="row g-3 mb-6" action="" method="POST">
                <input type="hidden" name="nurse_ID" id="nurse_ID" class="form-control error_input" value="<?php echo $nurse_ID; ?>">
                <input type="hidden" name="contract_number" id="contract_number" class="form-control error_input" value="<?php echo $contract_number; ?>">
                <div class="col-sm-6 col-md-8">
                    <div class="form-floating"><input class="form-control" id="wound_description" name="wound_description" type="text" placeholder="Please describe the wound in details"><label for="wound_description">Please describe the wound in details</label></div>
                </div>
                <div class="col-sm-6 col-md-8">
                    <input type="date" class="form-control" id="care_start_date" name="care_start_date" placeholder="Enter phone number" value="" style="padding: 15px;">
                </div>
                <div class="col-sm-6 col-md-8">
                    <button type="submit" name="assign_nurse" id="assign_nurse" class="btn btn-primary w-100 mb-0">Assign Nurse</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
include("../../includes/footer.php");
?>