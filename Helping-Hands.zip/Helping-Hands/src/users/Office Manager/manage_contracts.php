<?php
session_start();
include("../../database/db.php");
include('../../Global/functions.php');
include("../../includes/header.php");
include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");
// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}
// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

//check the parameters if they are set

if (isset($_GET['status'])) {
    $status = $_GET['status'];
} else {
    $status = "A";
}


// Your HTML and other content for the Admin dashboard
$alertMessage = "";


$query = "SELECT * FROM nurse_profile WHERE user_ID = '$user_ID'";
$results =  mysqli_query($conn, $query);
$data = mysqli_fetch_all($results, MYSQLI_ASSOC);

$nurseID = [];

foreach ($data as $row) {
    // Access the patient_ID for each row and add it to the $patientIDs array
    $nurseID = $row['nurse_ID'];
    $nurseIDs[] = $nurseID;
}

$contractData = []; // Initialize an empty array to store contract data

// Assuming you already have the $patientIDs array from the previous code
foreach ($nurseIDs as $nurseID) {
    // Perform a new SQL query to select data from the contact table for each patient_ID
    $contactQuery = "SELECT * FROM care_contract WHERE nurse_ID = '$nurseID'";
    $contactResults = mysqli_query($conn, $contactQuery);
    $contactData = mysqli_fetch_all($contactResults, MYSQLI_ASSOC);

    foreach ($contactData as $contactRow) {
        $nurse_ID = $contactRow['nurse_ID'];

        // Now you can use $nurse_ID to perform queries related to the nurse_profile table
        $nurseQuery = "SELECT * FROM nurse_profile WHERE nurse_ID = '$nurse_ID'";
        $nurseResults = mysqli_query($conn, $nurseQuery);
        $nurseData = mysqli_fetch_assoc($nurseResults);
    }
}
$today = date("Y-m-d");
$rand = strtoupper(substr(uniqid(sha1(time())), 0, 4));


if (isset($_GET['manage_care_contract']) && $_GET['manage_care_contract'] == 'success') {
    $alertMessage = '<div class="alert alert-success" id="alert_error" role="alert">Your care contract has been successfully created</div>';
} else if (isset($_GET['manage_care_contract']) && $_GET['manage_care_contract'] == 'failed') {
    $alertMessage = '<div class="alert alert-danger" id="alert_error" role="alert">Something went wrong, as we cant save your request</div>';
}else if(isset($_GET['assign_status']) && $_GET['assign_status'] == 'yes'){
    $alertMessage = '<div class="alert alert-success" id="alert_error" role="alert">You have successfully assigned yourself in the contract</div>';
}
?>
<div id="add_care_contract" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create your own contract</h5>
                <button class="btn p-1" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="fas fa-times fs--1"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php foreach ($data as $row) { ?>
                    <form class="main_form" action="" method="POST">
                        <div class="mb-3">

                            <input type="hidden" name="patient_ID" id="patient_ID" class="form-control error_input" value="<?php echo $contactRow['patient_ID']; ?>">

                        </div>
                        <div class="mb-3">
                            <label for="city_abr" class="form-label form_label">Where do you want the contract to be?</label>
                            <select type="number" name="city_ID" id="city_ID" class="form-control error_input">
                                <option selected>Open this select menu</option>
                                <?php

                                @include '../../database/db.php';

                                $results = mysqli_query($conn, "SELECT `city_ID`,`city_name` FROM `city`");

                                while ($data = mysqli_fetch_array($results)) {
                                    echo "<option value='" . $data['city_ID'] . "'>" . $data['city_name'] . "</option>";
                                }

                                ?>
                            </select>
                            <span id="error_city_ID" class="error"></span>
                        </div>

                        <div class="mb-3">
                            <label for="suburb_ID" class="form-label form_label">Where do you want the contract to be?</label>
                            <select type="number" name="suburb_ID" id="suburb_ID" class="form-control error_input">
                                <option selected>Open this select menu</option>

                            </select>
                            <span id="error_city_ID" class="error"></span>
                        </div>


                        <div>
                            <button type="submit" name="add_care_contract" id="add_care_contract" class="btn btn-primary w-100 mb-0">Create Care Contract</button>
                        </div>
                    </form>
                <?php } ?>
            </div>
        </div>

    </div>
</div>

<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage; ?>

            </div>
        <?php } ?>

    </div>
    <div class="row align-items-center justify-content-between g-3 mb-4">
        <div class="col-auto">
            <h2 class="mb-0">Care Contract </h2>
        </div>
        <div class="col-auto">


            <div class="dropdown font-sans-serif d-inline-block">
                <button class="btn btn-phoenix-secondary dropdown-toggle" id="dropdownMenuButton" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Filter the table</button><span class="caret"> </span>
                <div class="dropdown-menu dropdown-menu-end py-0" aria-labelledby="dropdownMenuButton" style="">
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=N">New Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=A">Active Contracts</a>
                    <a class="dropdown-item" href="/Helping-Hands/src/users/Nurse/manage_contracts.php/?status=C">Closed Contracts</a>
                </div>
            </div>

            <button class="btn btn-phoenix-primary" data-bs-toggle="modal" data-bs-target="#add_care_contract">
                <span class="fa-solid fa-plus me-2"></span> Create Care Contract
            </button>
        </div>
    </div>
    <div class="mx-n4 px-4 mx-lg-n6 px-lg-6 bg-white border-top border-bottom border-200 position-relative top-1">
        <div class="table-responsive scrollbar mx-n1 px-1">
            <table class="table table-sm fs--1 mb-0">
                <thead>
                    <tr>

                        <th class="sort align-middle">Assigned Nurse</th>
                        <th class="sort align-middle">Nurse Code</th>
                        <th class="sort align-middle">Status</th>
                        <th class="sort align-middle">Wound Description</th>
                        <th class="sort align-middle">Contract Start</th>
                        <th class="sort align-middle">Start Date</th>
                        <th class="sort align-middle">End Date</th>
                        <th class="sort align-middle">Action</th>
                    </tr>
                </thead>

                <tbody class="list" id="order-table-body">
                    <?php
                    foreach ($nurseIDs as $nurseID) {
                        // Query the care_contract table for each patient_ID
                        $contactQuery = "SELECT cc.*, np.* FROM care_contract cc LEFT JOIN nurse_profile np ON np.nurse_ID = cc.nurse_ID WHERE care_contract_status = '$status'/* active_status = 'Y' *//* WHERE nurse_ID = '$nurseID' AND active_status = 'Y' AND care_contract_status = '$status' */";
                        $contactResults = mysqli_query($conn, $contactQuery);
                        $contactData_main = mysqli_fetch_all($contactResults, MYSQLI_ASSOC);

                        foreach ($contactData_main as $contactRow_main) {
                            /* $nurse_ID = $contactRow['nurse_ID'];

                            // Now you can use $nurse_ID to perform queries related to the nurse_profile table
                            $nurseQuery = "SELECT * FROM nurse_profile WHERE nurse_ID = '$nurse_ID'";
                            $nurseResults = mysqli_query($conn, $nurseQuery);
                            $nurseData = mysqli_fetch_assoc($nurseResults); */
                    ?>
                            <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                                <input type="hidden" name="nurse_ID" id="nurse_ID" class="form-control error_input" value="<?php echo isset($contactRow_main['nurse_ID']) ? $contactRow_main['nurse_ID'] : 'Not Set'; ?>">
                                <td class="sort align-middle fw-bold"><?php echo !empty($contactRow_main) ? $contactRow_main['first_name'] . ' ' . $contactRow_main['last_name'] : 'Not Assigned to Nurse'; ?></td>
                                <td class="sort align-middle"><?php echo isset($contactRow_main['nurse_code']) ? $contactRow_main['nurse_code'] : 'No Nurse Code'; ?></td>
                                <td class="sort align-middle">
                                    <?php
                                    $final = false;
                                    if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'C') {
                                        echo '<span class="badge badge-phoenix fs--2 badge-phoenix-danger"><span class="badge-label">Closed</span><span class="ms-1" data-feather="x" style="height:12.8px;width:12.8px;"></span></span>';
                                        $final = true;
                                    } else if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'A') {
                                        echo '<span class="badge badge-phoenix fs--2 badge-phoenix-success"><span class="badge-label">Active</span><span class="ms-1" data-feather="x" style="height:12.8px;width:12.8px;"></span></span>';
                                        $final = false;
                                    } else {
                                        echo '<span class="badge badge-phoenix fs--2 badge-phoenix-warning"><span class="badge-label">Not Active</span><span class="ms-1" data-feather="x" style="height:12.8px;width:12.8px;"></span></span>';
                                    }
                                    ?>
                                </td>
                                <td class="sort align-middle"><?php echo isset($contactRow_main['wound_description']) ? $contactRow_main['wound_description'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($contactRow_main['contract_date']) ? $contactRow_main['contract_date'] : 'N/A'; ?></td>
                                <td class="sort align-middle"><?php echo isset($contactRow_main['care_start_date']) ? $contactRow_main['care_start_date'] : 'Not set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($contactRow_main['care_end_date']) ? $contactRow_main['care_end_date'] : 'Not Set'; ?></td>

                                <td class="sort align-middle">
                                    <?php
                                    if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'N') {
                                        echo '<a type="submit" class="btn btn-phoenix-warning" name="view_care_contract" id="view_care_contract" href="/Helping-Hands/src/users/Nurse/assign_contract.php?nurse_ID='.$contactRow['nurse_ID'].'&contract_number='.$contactRow_main['contract_number'].'">
                                            Assign this to me
                                        </a>';
                                    } else if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'A') {
                                        
                                        echo '<a type="submit" class="btn btn-phoenix-warning" name="view_care_contract" id="view_care_contract" href="/Helping-Hands/src/users/Nurse/schedule_visit.php?nurse_ID='.$contactRow['nurse_ID'].'&contract_number='.$contactRow_main['contract_number'].'&patient_ID='.$contactRow_main['patient_ID'].'">
                                            Visit Schedule
                                        </a>';
                                    } else if (isset($contactRow_main['care_contract_status']) && $contactRow_main['care_contract_status'] === 'C') {
                                        echo '<a type="submit" class="btn btn-phoenix-warning" name="view_care_contract" id="view_care_contract" data-bs-toggle="modal" data-bs-target="#view_care_contract">
                                            <span class="fa-solid fa-user-nurse me-2">Assign this to me</span>
                                        </a>';
                                    }
                                    ?>
                                </td>
                            </tr>
 
                    <?php
                        }
                    }
                    ?>
                </tbody>

            </table>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }

    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>
<script type="text/javascript">
    // Get a reference to the input element and the character count span
    const inputElement = document.getElementById("about_patient");
    const countElement = document.getElementById("count_car");

    // Add an input event listener to the input element
    inputElement.addEventListener("input", function() {
        // Get the current value and length of the input
        const inputValue = inputElement.value;
        const currentLength = inputValue.length;
        const maxLength = 100;


        // Set the character count in the span

        //countElement.textContent = `(${100 - currentLength})`;

        // You can add additional logic here, such as disabling the input when it reaches the maximum length.
        if (currentLength > maxLength) {
            inputElement.value = inputValue.slice(0, maxLength);
        }

        // Set the character count in the span
        countElement.textContent = `(${maxLength - currentLength})`;
    });
</script>
<script>
    document.getElementById("city_ID").addEventListener("change", function() {
        // Get the selected city_ID
        var selectedCity = this.value;

        // Use AJAX to send a request to the server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_suburbs_ajax_call.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the JSON response and populate the suburb dropdown
                var suburbs = JSON.parse(xhr.responseText);
                var suburbDropdown = document.getElementById("suburb_ID");
                suburbDropdown.innerHTML = "<option selected>Select a suburb</option>";

                suburbs.forEach(function(suburb) {
                    var option = document.createElement("option");
                    option.value = suburb.suburb_ID;
                    option.textContent = suburb.suburb_name;
                    suburbDropdown.appendChild(option);
                });
            }
        };

        // Send the request with the selected city
        xhr.send("city_ID=" + selectedCity);
    });
</script>

<?php
include("../../includes/footer.php");
?>