<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_ID'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: ../../signin.php?signin=you_are_not_signed_in");
    exit();
}

// Access the user information from the session
$user_ID = $_SESSION['user_ID'];
$email_address = $_SESSION['email_address'];

// Your HTML and other content for the Admin dashboard
include("../../database/db.php");

include("../../includes/sidebar.php");
include("../../includes/top_navigation.php");



$alertMessage = '';

if (isset($_GET['admin_dashboard']) && $_GET['admin_dashboard'] == 'city_empty') {
    $alertMessage = '
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error!</strong> The City Name and Abbreviation can not be empty.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
  ';
} else if (isset($_GET['admin_dashboard']) && $_GET['admin_dashboard'] == 'city_added') {
    $alertMessage = '
  <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Congratulations!</strong> The City Name and Abbreviation have been added to database.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
  ';
}


$query = "SELECT np.*, user.user_ID
FROM nurse_profile np
INNER JOIN user user ON np.user_ID = user.user_ID
WHERE np.status = 'A'";

$result = mysqli_query($conn, $query);
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);


//add the nurse
if (isset($_POST['add_nurse'])) {

    //these are for the username
    $email_address = $_POST['email_address'];
    $contact_no = $_POST['contact_no'];
    $user_type = "N";
    $status = "A";

    //these are for the nurse table

    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $id_number = $_POST['id_number'];

    $first6Digits = substr($id_number, 0, 6);

    // Extract year, month, and day
    $year = substr($first6Digits, 0, 2);
    $month = substr($first6Digits, 2, 2);
    $day = substr($first6Digits, 4, 2);

    // Determine the century based on the year (assuming 20th century for years less than or equal to the current year)
    $currentYear = date("Y");
    if ($year <= intval(substr($currentYear, 2))) {
        $century = "20"; // For years less than or equal to the current year
    } else {
        $century = "19"; // For years greater than the current year
    }

    // Create the date in YYYY-MM-DD format
    $dateOfBirth = $century . $year . "-" . $month . "-" . $day;

    $dob = $dateOfBirth;


    // Extract the first 3 letters from first_name and last_name
    $first_name_initials = substr($first_name, 0, 3);
    $last_name_initials = substr($last_name, 0, 3);

    // Generate a random 3-digit number (between 1 and 999)
    $random_number = rand(1, 999);
    $random_number_padded = str_pad($random_number, 3, '0', STR_PAD_LEFT);

    // Combine the initials and the random number to create the nurse_code
    $nurse_code = strtoupper($first_name_initials . $last_name_initials) . $random_number_padded;


    //username will combine the first 3 letter of name and surname
    $first_name_short = substr($first_name, 0, 3);
    // Remove spaces from the last name and get the last name (or first 3 letters if it's longer)
    $last_name = str_replace(' ', '', $last_name);
    $last_name_short = substr($last_name, 0, 3);
    // Generate a random number between 1 and 99
    $random_number = rand(1, 99);
    // Create the username
    $username = $first_name_short . $last_name_short . '@' . str_pad($random_number, 2, '0', STR_PAD_LEFT);

    //generate password
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $specialChars = '!@#$%^&*()_+[]{}|;:,.<>?';
    $requiredChars = $uppercase . $lowercase . $numbers . $specialChars;
    $password = $uppercase[rand(0, strlen($uppercase) - 1)] .
        $lowercase[rand(0, strlen($lowercase) - 1)] .
        $numbers[rand(0, strlen($numbers) - 1)] .
        $specialChars[rand(0, strlen($specialChars) - 1)];

    for ($i = 0; $i < 8; $i++) {
        $password .= $requiredChars[rand(0, strlen($requiredChars) - 1)];
    }

    // Shuffle the password to randomize character order
    $password = str_shuffle($password);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    //INSERT INTO THE USER TABLE
    $query = "INSERT INTO user (username, email_address, password, contact_no, user_type) VALUES ('$username','$email_address','$hashed_password','$contact_no', '$user_type')";
    $results = mysqli_query($conn, $query);

    if ($results) {

        //now lets add the others on nurse profile
        $query_nurse = "INSERT INTO nurse_profile (user_ID, first_name, last_name, nurse_code, gender, id_number, dob, status) VALUES ('$user_ID','$first_name','$last_name','$nurse_code', '$gender', '$id_number', '$dob', '$status')";
        $results_nurse = mysqli_query($conn, $query_nurse);

        if ($results_nurse) {
            $alertMessage = '
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong> The City Name and Abbreviation have been added to database.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            ';
        } else {
            header("Location: manage_nurse.php/?manage_nurse=no");
        }
        /* $subject = "Helping Hands - Registration Success!";
        $message = "You are getting this email, because you have successful registered your account\n\n";
        $message .= "Use the following details that you have created to login:\n\n";
        $message .= "Username: $username\n\n";
        $message .= "Password: $password\n\n";
        //$message .= "Password: '.$password.'\n\n";
        $message .= "Please <a href='localhost:8003/signin.php'>Login now to complete your profile</a>\n\n";
        $to = "viwemhlabaremote@gmail.com";
        $headers = "From: noreply@helpinghands.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();


        $mailSent = mail($to, $subject, $message, $headers);

        if ($mailSent) {
            header("Location: ../manage_nurse.php?manage_nurse=nurse_added");
        } else {
            header("Location: ../manage_nurse.php?manage_nurse=nurse_not_added");
        } */
    } 
}
include("../../includes/header.php");
?>

<div id="add_cities" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Nurse</h5>
                <button class="btn p-1" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="fas fa-times fs--1"></span>
                </button>
            </div>
            <div class="modal-body">
                <form class="main_form_signup" action="" method="POST">
                    <div class="alert alert-danger hide" id="alert_error" role="alert">One or more fields are empty</div>
                    <div class="row flex-between-center mb-3">
                        <div class="col">
                            <input type="text" name="first_name" id="first_name" class="form-control form-icon-input" placeholder="Enter your name">
                        </div>
                        <div class="col">
                            <input type="text" name="last_name" id="last_name" class="form-control form-icon-input" placeholder="Enter your surname">
                        </div>

                    </div>
                    <div class="row flex-between-center mb-3">
                        <div class="col">
                            <input type="email" name="email_address" id="email_address" class="form-control form-icon-input" placeholder="Email address">
                        </div>
                        <div class="col">
                            <input type="number" name="id_number" id="id_number" class="form-control form-icon-input" placeholder="Enter your Id Number">
                        </div>

                    </div>
                    <div class="mb-3 text-start">
                        <div class="form-icon-container">
                            <input type="number" class="form-control form-icon-input" id="contact_no" name="contact_no" type="text" placeholder="Contact Number">
                        </div>
                    </div>
                    <div class="mb-3 flex-between-center mb-3">
                        <select type="text" name="gender" id="gender" class="form-select form-control" aria-label="Default select example">
                            <option selected>Select gender</option>
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                    <button class="btn btn-primary w-100 mb-3" name="add_nurse" id="add_nurse">Add Nurse</button>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="row">
        <?php if (isset($alertMessage)) { ?>
            <div class="col">
                <?php echo $alertMessage ?>
            </div>
        <?php } ?>

    </div>

    <div class="row gy-3 mb-6 justify-content-between">
        <div class="col-md-8 col-auto">
            <h2 class="mb-2 text-1100">Manage Nurses</h2>
            <h5 class="text-700 fw-semi-bold">Add and view the list of nurses</h5>
        </div>
        <div class="col-md-4 col-auto">
            <button class="btn btn-sm btn-primary ml-3 mt-2" data-bs-toggle="modal" data-bs-target="#add_cities">
                Add More Nurse +
            </button>
        </div>
    </div>


    <div class="row mx-n4 px-4 mx-lg-n6 px-lg-6 bg-white border-top border-bottom border-200 position-relative top-1">
    
            <div class="table-responsive scrollbar mx-n1 px-1">
                <table class="table table-sm fs--1 mb-0">
                    <thead>
                        <tr>
                            <th class="sort align-middle">Nurse Code</th>
                            <th class="sort align-middle">First Name</th>
                            <th class="sort align-middle">Last Name</th>
                            <th class="sort align-middle">Email</th>
                            <th class="sort align-middle">Contact Number</th>
                            <th class="sort align-middle">Id Number</th>
                            <th class="sort align-middle">Gender</th>
                            <th class="sort align-middle">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($data as $row) {
                        ?>
                            <!--HTML OR MAIN TABLE HERE-->
                            <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                                <td class="sort align-middle"><?php echo isset($row['nurse_code']) ? $row['nurse_code'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['first_name']) ? $row['first_name'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['last_name']) ? $row['last_name'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['email_address']) ? $row['email_address'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['contact_no']) ? $row['contact_no'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['id_number']) ? $row['id_number'] : 'Not Set'; ?></td>
                                <td class="sort align-middle"><?php echo isset($row['gender']) ? $row['gender'] : 'Not Set'; ?></td>


                                <td class="sort align-middle">
                                    <a class="btn btn-primary" href="view_care_service.php?contract_number=<?php echo isset($row['nurse_ID']) ? $row['nurse_ID'] : 'Not Set'; ?>"><span class="fa-solid fa-pen-to-square"></span></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Function to fetch and display the number of unread notifications
    function fetchUnreadNotifications() {
        $.ajax({
            url: 'check_notifications.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Display the number of unread notifications
                const unreadCount = data.length;
                const unreadNotificationsElement = document.getElementById('unread-notifications');
                unreadNotificationsElement.textContent = `${unreadCount}`;
            }
        });
    }

    // Fetch the number of unread notifications every 5 seconds (adjust as needed)
    setInterval(fetchUnreadNotifications, 5000);

    // Initial fetch
    fetchUnreadNotifications();
</script>

<!-- <script>
    $('#add_cities').on('shown.bs.modal', function() {
        $('#myInput').trigger('focus')
    })
</script> -->

<?php
include("../../includes/footer.php");
?>