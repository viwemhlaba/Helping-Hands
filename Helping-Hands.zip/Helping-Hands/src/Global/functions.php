<?php
//session_start();
date_default_timezone_set('Africa/Johannesburg');
//include('../database/db.php');

function update_city($conn, $newCityName, $newCityAbr, $cityIDNew)
{
    $updateCity = "UPDATE city SET city_name = '{$newCityName}', city_abr = '{$newCityAbr}' WHERE city_ID = {$cityIDNew}";
    //$updateCity = "CALL GetPatientProfileInfo($newCityName, $newCityAbr, $cityIDNew)";
    $updateCity_results = mysqli_query($conn, $updateCity);

    //$user_ID_NEW = $user_ID;
    
    
    if ($updateCity_results) {
        echo 'City successfully Updated';
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    return $updateCity_results;
}

function update_profile($conn, $user_ID, $email_address, $contact_no, $first_name, $last_name, $id_number, $dob, $profile_picture, $about_patient, $street_name_add, $suburb_ID, $ec_person, $ecp_number, $fb_link, $insta_link) {
    // Create a prepared statement for user table update
    $update_user_table_query = "UPDATE user SET email_address = ?, contact_no = ? WHERE user_ID = ?";
    $stmt_user = mysqli_prepare($conn, $update_user_table_query);

    if (!$stmt_user) {
        return 'Error creating prepared statement for user table';
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt_user, "ssi", $email_address, $contact_no, $user_ID);

    // Execute the statement for user table
    if (!mysqli_stmt_execute($stmt_user)) {
        return 'Error updating user table';
    }

    // Close the statement for user table
    mysqli_stmt_close($stmt_user);

    // Create a prepared statement for patient_profile update
    $update_patient_profile_table_query = "UPDATE patient_profile SET first_name = ?, last_name = ?, id_number = ?, dob = ?, profile_picture = ?, about_patient = ?, street_name_add = ?, suburb_ID = ?, ec_person = ?, ecp_number = ?, fb_link = ?, insta_link = ? WHERE user_ID = ?";
    $stmt_patient_profile = mysqli_prepare($conn, $update_patient_profile_table_query);

    if (!$stmt_patient_profile) {
        return 'Error creating prepared statement for patient_profile table';
    }

    // Bind parameters for patient_profile
    mysqli_stmt_bind_param($stmt_patient_profile, "ssissssisissi", $first_name, $last_name, $id_number, $dob, $profile_picture, $about_patient, $street_name_add, $suburb_ID, $ec_person, $ecp_number, $fb_link, $insta_link, $user_ID);

    // Execute the statement for patient_profile
    if (!mysqli_stmt_execute($stmt_patient_profile)) {
        return 'Error updating patient_profile table';
    }

    // Close the statement for patient_profile
    mysqli_stmt_close($stmt_patient_profile);

    return 'Profile updated successfully';
}

function update_profile_nurse($conn, $user_ID, $email_address, $contact_no, $suburb_ID, $first_name, $last_name, $id_number, $dob, $gender, $nurse_code) {
    // Create a prepared statement for user table update
    $update_user_table_query = "UPDATE user SET email_address = ?, contact_no = ? WHERE user_ID = ?";
    $stmt_user = mysqli_prepare($conn, $update_user_table_query);

    if (!$stmt_user) {
        return 'Error creating prepared statement for user table';
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt_user, "ssi", $email_address, $contact_no, $user_ID);

    // Execute the statement for user table
    if (!mysqli_stmt_execute($stmt_user)) {
        return 'Error updating user table';
    }

    // Close the statement for user table
    mysqli_stmt_close($stmt_user);

    // Create a prepared statement for patient_profile update
    $update_patient_profile_table_query = "UPDATE nurse_profile SET suburb_ID = ?, first_name = ?, last_name = ?, id_number = ?, dob = ?, gender = ?, nurse_code = ? WHERE user_ID = ?";
    $stmt_patient_profile = mysqli_prepare($conn, $update_patient_profile_table_query);

    if (!$stmt_patient_profile) {
        return 'Error creating prepared statement for patient_profile table';
    }

    // Bind parameters for patient_profile
    mysqli_stmt_bind_param($stmt_patient_profile, "ississii", $suburb_ID, $first_name, $last_name, $id_number, $dob, $gender, $nurse_code, $user_ID);

    // Execute the statement for patient_profile
    if (!mysqli_stmt_execute($stmt_patient_profile)) {
        return 'Error updating patient_profile table';
    }

    // Close the statement for patient_profile
    mysqli_stmt_close($stmt_patient_profile);

    return 'Profile updated successfully';
}