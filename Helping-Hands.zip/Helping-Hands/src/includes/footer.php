</main>
<!-- ===============================================-->
<!--    JavaScripts-->
<!-- ===============================================-->
<script src="/Helping-Hands/src/assets/js/main.js"></script>
<!-- <script src="/Helping-Hands/src/assets/js/popper.min.js"></script> -->
<script src="/Helping-Hands/src/assets/js/popper.min.js"></script>
<script src="/Helping-Hands/src/assets/js/bootstrap.min.js"></script>
<script src="/Helping-Hands/src/assets/js/anchor.min.js"></script>
<script src="/Helping-Hands/src/assets/js/is.min.js"></script>
<script src="/Helping-Hands/src/assets/js/all.min.js"></script>
<script src="/Helping-Hands/src/assets/js/lodash.min.js"></script>
<script src="/Helping-Hands/src/assets/js/polyfill.min.js"></script>
<script src="/Helping-Hands/src/assets/js/list.min.js"></script>
<script src="/Helping-Hands/src/assets/js/feather.min.js"></script>
<script src="/Helping-Hands/src/assets/js/dayjs.min.js"></script>
<script src="/Helping-Hands/src/assets/js/phoenix.js"></script>
<script src="/Helping-Hands/src/assets/js/echarts.min.js"></script>
<script src="/Helping-Hands/src/assets/js/leaflet.js"></script>
<script src="/Helping-Hands/src/assets/js/leaflet.markercluster.js"></script>
<script src="/Helping-Hands/src/assets/js/leaflet-tilelayer-colorfilter.min.js"></script>
<script src="/Helping-Hands/src/assets/js/ecommerce-dashboard.js"></script>
<script src="/Helping-Hands/src/assets/js/flatpickr.js"></script>

</body>

</html>